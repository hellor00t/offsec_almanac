### Host Workflow
Tags: #workflow
Related to: 
See also: 
Previous:

### Scoping/Passive Enumeration

* OSINT
	* [OSINTFramework]([https://osintframework.com/](https://osintframework.com/))


### Initial Enumeration

Ports

[nmap](Recon/nmap)

### References