### Tool Setup
Tags: #workflow, #setup
Link:

---

### File Structure

```

- target_name
-- recon
-- creds
-- payloads

```

### BurpPro

Burp Regex for Scope Control

````
.*\.domain\.com$
````

---

### References

- https://m0chan.github.io/2019/12/17/Bug-Bounty-Cheetsheet.html


